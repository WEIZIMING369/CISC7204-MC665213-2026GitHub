print("My name is Student author, my student number is [student ID removed]")
