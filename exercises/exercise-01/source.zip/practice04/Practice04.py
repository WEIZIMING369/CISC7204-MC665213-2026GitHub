'''
Created on 2026年8月25日

@author: Wei
'''
name = input("Enter your name: ")
print("Hello,",name)